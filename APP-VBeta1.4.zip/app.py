import os
import json
import requests
import math
from flask import Flask, render_template, request, jsonify
from openai import OpenAI

app = Flask(__name__)

MEMORY_FILE = "coach_memory.dat"
# Création du fichier au démarrage s'il n'existe pas
if not os.path.exists(MEMORY_FILE):
    open(MEMORY_FILE, 'w', encoding='utf-8').close()

def get_coach_memory_summary():
    """Lit l'historique et génère un résumé des erreurs pour le prompt IA"""
    try:
        with open(MEMORY_FILE, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        trades = [json.loads(line) for line in lines if line.strip()]
        if not trades:
            return "\n\n[MÉMOIRE DU COACH] Aucun historique de trade pour le moment."

        total = len(trades)
        wins = len([t for t in trades if t.get('result') == 'WIN'])
        win_rate = (wins / total) * 100

        losses = [t for t in trades if t.get('result') == 'LOSS']
        recent_losses = losses[-3:] # On prend les 3 dernières erreurs

        summary = f"\n\n[MÉMOIRE DU COACH] Historique global : {total} trades analysés (Taux de réussite: {win_rate:.1f}%).\n"
        if recent_losses:
            summary += "IMPORTANT - Apprends de tes récentes ERREURS (Stop Loss touchés) :\n"
            for idx, l in enumerate(recent_losses):
                summary += f"- Erreur sur un setup {l.get('type')} basé sur '{l.get('reason')}'.\n"
            summary += "Adapte ton analyse actuelle pour être beaucoup plus strict si tu vois des conditions similaires à ces erreurs.\n"
        return summary
    except Exception as e:
        return f"\n[Erreur de lecture de la mémoire: {str(e)}]"


KEYS_FILE = "api_keys.json"

def load_keys():
    if os.path.exists(KEYS_FILE):
        with open(KEYS_FILE, 'r') as f:
            return json.load(f)
    return {"deepseek_key": "", "grok_key": "", "deepseek_model": "deepseek-chat", "grok_model": "grok-beta"}

def save_keys(keys):
    with open(KEYS_FILE, 'w') as f:
        json.dump(keys, f)

@app.route('/api/keys', methods=['GET', 'POST'])
def manage_keys():
    if request.method == 'POST':
        save_keys(request.json)
        return jsonify({"status": "success"})
    return jsonify(load_keys())

@app.route('/api/analyze', methods=['POST'])
def analyze_chart():
    data = request.json
    ai_type = data.get('ai_type')
    context = data.get('context', '')
    strategy = data.get('strategy', 'SMC Multi-Stratégies')
    keys = load_keys()
    
    if "Builder Modulaire" in strategy:
        system_prompt = f"""Tu es un Ingénieur Quantitatif. Modèle : {strategy}.
Analyse les confluences mathématiques choisies par l'utilisateur (Algo, Variance, L2, Optimisation, Convexe, Linéaire).
Réponds UNIQUEMENT avec ce format HTML :
<div style="color:white;">
    <div style="margin-bottom:8px;">🎯 <b>Verdict Custom :</b> [Attendre / Entrer LONG / Entrer SHORT]</div>
    <div style="margin-bottom:8px;">🟢 <b>Entrée Opti. :</b> [Prix]</div>
    <div style="margin-bottom:8px;">🔴 <b>Stop Loss :</b> [Prix]</div>
    <div style="margin-bottom:8px;">💰 <b>Take Profit :</b> [Prix projeté]</div>
    <div style="margin-top:10px; padding-top:10px; border-top:1px solid #4a5056; font-style:italic; color:#fdd835;">
        🧪 <b>Analyse des Confluences :</b> [Explique pourquoi les briques sélectionnées s'alignent].
    </div>
</div>"""
    elif "Quant V2" in strategy:
        system_prompt = f"""Tu es un Lead Quant Researcher. Modèle : {strategy}.
Analyse les données du modèle V2 (Filtre de Kalman, Lambda Dynamique ATR, Convexité 2nd degré).
Réponds UNIQUEMENT avec ce format HTML :
<div style="color:white;">
    <div style="margin-bottom:8px;">🎯 <b>Verdict Quant V2 :</b> [Attendre / Entrer LONG / Entrer SHORT]</div>
    <div style="margin-bottom:8px;">🟢 <b>Entrée Opti. :</b> [Prix]</div>
    <div style="margin-bottom:8px;">🔴 <b>Stop Loss :</b> [Prix]</div>
    <div style="margin-bottom:8px;">💰 <b>Take Profit :</b> [Prix projeté]</div>
    <div style="margin-top:10px; padding-top:10px; border-top:1px solid #4a5056; font-style:italic; color:#00e5ff;">
        🧬 <b>Thèse Algorithmique :</b> [Explique la probabilité et la convexité polynomiale].
    </div>
</div>"""
    elif "Quant" in strategy:
        system_prompt = f"""Tu es un Ingénieur Quantitatif. Modèle ciblé : {strategy}.
Analyse les probabilités (Régression L2, Optimisation Convexe, POC).
Réponds UNIQUEMENT avec ce format HTML :
<div style="color:white;">
    <div style="margin-bottom:8px;">🎯 <b>Verdict Quant :</b> [Attendre / Entrer LONG / Entrer SHORT]</div>
    <div style="margin-bottom:8px;">🟢 <b>Entrée Opti. :</b> [Prix]</div>
    <div style="margin-bottom:8px;">🔴 <b>Stop Loss :</b> [Prix]</div>
    <div style="margin-bottom:8px;">💰 <b>Take Profit :</b> [Prix]</div>
    <div style="margin-top:10px; padding-top:10px; border-top:1px solid #4a5056; font-style:italic; color:#e040fb;">
        🧠 <b>Thèse Mathématique :</b> [Explique la convergence L2 et POC].
    </div>
</div>"""
    else:
        system_prompt = f"""Tu es un Coach de Trading SMC. Stratégies ciblées : {strategy}.
Analyse les confluences fournies. Réponds UNIQUEMENT avec ce format HTML :
<div style="color:white;">
    <div style="margin-bottom:8px;">🎯 <b>Verdict IA :</b> [Attendre / Entrer LONG / Entrer SHORT]</div>
    <div style="margin-bottom:8px;">🟢 <b>Entrée :</b> [Prix]</div>
    <div style="margin-bottom:8px;">🔴 <b>Stop Loss :</b> [Prix]</div>
    <div style="margin-bottom:8px;">💰 <b>Take Profit :</b> [Prix]</div>
    <div style="margin-top:10px; padding-top:10px; border-top:1px solid #4a5056; font-style:italic; color:#ff9800;">
        🧠 <b>Analyse Institutionnelle :</b> [Explique les confluences : OB, FVG, Liquidity].
    </div>
</div>"""

    try:
        # INJECTION DE LA MÉMOIRE DANS LE PROMPT
        memory_summary = get_coach_memory_summary()
        system_prompt += memory_summary

        if ai_type == 'deepseek':
            if not keys.get('deepseek_key'): return jsonify({"error": "Clé Deepseek manquante."}), 400
            client = OpenAI(api_key=keys.get('deepseek_key'), base_url="https://api.deepseek.com")
            response = client.chat.completions.create(model=keys.get('deepseek_model', 'deepseek-chat'), messages=[{"role": "system", "content": system_prompt}, {"role": "user", "content": context}], stream=False, max_tokens=450, temperature=0.3)
            return jsonify({"response": response.choices[0].message.content})
        elif ai_type == 'grok':
            if not keys.get('grok_key'): return jsonify({"error": "Clé Grok manquante."}), 400
            headers = {"Content-Type": "application/json", "Authorization": f"Bearer {keys.get('grok_key')}"}
            payload = {"model": keys.get('grok_model', 'grok-beta'), "messages": [{"role": "system", "content": system_prompt}, {"role": "user", "content": context}], "stream": False, "temperature": 0.3}
            grok_req = requests.post("https://api.x.ai/v1/chat/completions", headers=headers, json=payload)
            grok_res = grok_req.json()
            if grok_req.status_code == 200: return jsonify({"response": grok_res['choices'][0]['message']['content']})
            else: return jsonify({"error": f"Erreur Grok : {grok_res.get('error', 'Erreur')}"}), 400
        else: return jsonify({"error": "Type d'IA invalide"}), 400
    except Exception as e: return jsonify({"error": f"Erreur Serveur : {str(e)}"}), 500



@app.route('/api/sl_params', methods=['GET'])
def optimize_sl():
    try:
        # VERIFICATION: S'assurer que le fichier existe
        if not os.path.exists(MEMORY_FILE):
            open(MEMORY_FILE, 'w', encoding='utf-8').close()

        with open(MEMORY_FILE, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        trades = [json.loads(line) for line in lines if line.strip()]

        atr_mult = 2.0
        rr_target = 2.0

        if len(trades) > 3:
            losses = [t for t in trades if t.get('result') == 'LOSS']
            win_rate = (len(trades) - len(losses)) / len(trades)

            # Intelligence du coach : Si trop de Stop Loss touchés (win rate bas), on éloigne le SL
            if win_rate < 0.40:
                atr_mult = 3.0  # On donne plus d'espace au trade
            # Si très précis, on peut resserrer pour un meilleur ratio
            elif win_rate > 0.65:
                atr_mult = 1.5
            else:
                atr_mult = 2.2

        return jsonify({"atr_multiplier": atr_mult, "rr_target": rr_target, "trades_count": len(trades)})
    except Exception as e:
        return jsonify({"atr_multiplier": 2.0, "rr_target": 2.0, "error": str(e)})

@app.route('/api/learn', methods=['POST'])
def learn_from_trade():
    data = request.json
    try:
        with open(MEMORY_FILE, "a", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
            f.write("\n")
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500



@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
