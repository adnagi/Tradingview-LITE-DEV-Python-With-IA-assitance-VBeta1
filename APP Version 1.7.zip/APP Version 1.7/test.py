import traceback
import sys
import os

print("=== DEBUT DU TEST DE DEBUG SMC ===")
print(f"Version Python : {sys.version}")

# Etape 1 : Test des dépendances de base
print("\n--- TEST 1 : IMPORT PANDAS ---")
try:
    import pandas as pd
    print(f"✅ Pandas importé avec succès. Version : {pd.__version__}")
except Exception as e:
    print("❌ ECHEC Pandas :")
    traceback.print_exc()

# Etape 2 : Test de Smart Money Concepts
print("\n--- TEST 2 : IMPORT SMC ---")
try:
    import smartmoneyconcepts
    print("✅ Librairie 'smartmoneyconcepts' trouvée.")
    from smartmoneyconcepts import smc
    print("✅ Module 'smc' importé avec succès.")
except Exception as e:
    print("❌ ECHEC SMC :")
    traceback.print_exc()

# Etape 3 : Test de création d'un graphique bidon
if 'smc' in locals():
    print("\n--- TEST 3 : CALCUL DES FVG ---")
    try:
        # Création de bougies fictives
        data = {
            'open': [10, 11, 12, 13, 14, 15],
            'high': [12, 13, 14, 15, 16, 17],
            'low': [9, 10, 11, 12, 13, 14],
            'close': [11, 12, 13, 14, 15, 16],
            'volume': [100, 110, 120, 130, 140, 150]
        }
        df = pd.DataFrame(data)
        
        fvg_df = smc.fvg(df)
        print("✅ Fonction fvg() exécutée avec succès.")
        print(fvg_df.head())
        
        print("\n✅ TOUT FONCTIONNE PARFAITEMENT ! Le problème vient donc de Flask ou du format des données.")
        
    except Exception as e:
        print("❌ ECHEC lors du calcul de la fonction fvg() :")
        traceback.print_exc()
else:
    print("\n❌ Test ignoré car SMC n'a pas pu être importé à l'étape 2.")

print("\n=== FIN DU TEST ===")
