import os
import json
import requests
import math
from collections import defaultdict
from flask import Flask, render_template, request, jsonify, send_from_directory
from openai import OpenAI
try:
    from fusion_engine import FusionEngine, MemoryManager
except ImportError:
    pass


# --- TENTATIVE D'IMPORTATION DE SMC ---
try:
    import pandas as pd
    import time
    import logging
    from smartmoneyconcepts import smc
    SMC_AVAILABLE = True
except ImportError:
    SMC_AVAILABLE = False
    print("⚠️ 'pandas' ou 'smartmoneyconcepts' non installé. Le moteur SMC Python sera désactivé.")

app = Flask(__name__)

MEMORY_FILE = "coach_memory.dat"

# Création du fichier au démarrage s'il n'existe pas
if not os.path.exists(MEMORY_FILE):
    open(MEMORY_FILE, 'w', encoding='utf-8').close()


def get_coach_memory_summary():
    """Lit l'historique et génère un résumé des erreurs pour le prompt IA"""
    try:
        with open(MEMORY_FILE, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        trades = [json.loads(line) for line in lines if line.strip()]
        if not trades:
            return "\n\n[MÉMOIRE DU COACH] Aucun historique de trade pour le moment."

        total = len(trades)
        wins = len([t for t in trades if t.get('result') == 'WIN'])
        win_rate = (wins / total) * 100
        losses = [t for t in trades if t.get('result') == 'LOSS']
        recent_losses = losses[-3:]  # On prend les 3 dernières erreurs

        summary = (
            f"\n\n[MÉMOIRE DU COACH] Historique global : {total} trades analysés "
            f"(Taux de réussite: {win_rate:.1f}%).\n"
        )
        if recent_losses:
            summary += "IMPORTANT - Apprends de tes récentes ERREURS (Stop Loss touchés) :\n"
            for l in recent_losses:
                summary += (
                    f"- Erreur sur un setup {l.get('type')} basé sur "
                    f"'{l.get('reason')}'.\n"
                )
            summary += (
                "Adapte ton analyse actuelle pour être beaucoup plus strict si tu vois "
                "des conditions similaires à ces erreurs.\n"
            )
        return summary
    except Exception as e:
        return f"\n[Erreur de lecture de la mémoire: {str(e)}]"


KEYS_FILE = "api_keys.json"


KRAKEN_SYMBOL_MAP = {
    "BTCUSDT": "BTC/USDT",
    "ETHUSDT": "ETH/USDT",
    "SOLUSDT": "SOL/USDT",
    "XRPUSDT": "XRP/USDT",
    "DOGEUSDT": "DOGE/USDT",
}

KRAKEN_INTERVAL_MAP = {
    "1m": 1,
    "5m": 5,
    "15m": 15,
    "30m": 30,
    "1h": 60,
    "4h": 240,
}


def normalize_binance_klines(rows):
    candles = []
    for row in rows or []:
        candles.append({
            "time": int(row[0] // 1000),
            "open": float(row[1]),
            "high": float(row[2]),
            "low": float(row[3]),
            "close": float(row[4]),
            "volume": float(row[5]),
            "source": "binance",
        })
    return candles


def fetch_binance_history(symbol, interval, limit=1000):
    response = requests.get(
        "https://data-api.binance.vision/api/v3/klines",
        params={"symbol": symbol, "interval": interval, "limit": min(int(limit), 1000)},
        timeout=20,
    )
    response.raise_for_status()
    return normalize_binance_klines(response.json())


def normalize_kraken_ohlc(payload):
    if payload.get("error"):
        raise ValueError(", ".join(payload["error"]))
    result = payload.get("result", {})
    pair_keys = [k for k in result.keys() if k != "last"]
    if not pair_keys:
        return []
    rows = result[pair_keys[0]]
    candles = []
    for row in rows:
        candles.append({
            "time": int(float(row[0])),
            "open": float(row[1]),
            "high": float(row[2]),
            "low": float(row[3]),
            "close": float(row[4]),
            "volume": float(row[6]),
            "source": "kraken",
        })
    return candles


def fetch_kraken_history(symbol, interval, limit=720):
    kraken_symbol = KRAKEN_SYMBOL_MAP.get(symbol)
    kraken_interval = KRAKEN_INTERVAL_MAP.get(interval)
    if not kraken_symbol:
        raise ValueError(f"Symbole Kraken non supporté: {symbol}")
    if not kraken_interval:
        raise ValueError(
            f"Timeframe Kraken non supporté: {interval}. Utilise 1m, 5m, 15m, 30m, 1h ou 4h."
        )

    response = requests.get(
        "https://api.kraken.com/0/public/OHLC",
        params={"pair": kraken_symbol, "interval": kraken_interval},
        timeout=20,
    )
    response.raise_for_status()
    candles = normalize_kraken_ohlc(response.json())
    return candles[-min(int(limit), 720):]


def merge_candles(binance_candles, kraken_candles):
    grouped = defaultdict(list)
    for candle in (binance_candles or []):
        grouped[candle["time"]].append(candle)
    for candle in (kraken_candles or []):
        grouped[candle["time"]].append(candle)

    merged = []
    for ts in sorted(grouped.keys()):
        items = grouped[ts]
        merged.append({
            "time": ts,
            "open": sum(x["open"] for x in items) / len(items),
            "high": sum(x["high"] for x in items) / len(items),
            "low": sum(x["low"] for x in items) / len(items),
            "close": sum(x["close"] for x in items) / len(items),
            "volume": sum(x["volume"] for x in items),
            "source": "merged" if len(items) > 1 else items[0].get("source", "merged"),
            "components": [x.get("source") for x in items],
        })
    return merged



def load_keys():
    if os.path.exists(KEYS_FILE):
        with open(KEYS_FILE, 'r') as f:
            return json.load(f)
    return {
        "deepseek_key": "",
        "grok_key": "",
        "deepseek_model": "deepseek-chat",
        "grok_model": "grok-beta",
    }


def save_keys(keys):
    with open(KEYS_FILE, 'w') as f:
        json.dump(keys, f)


@app.route('/api/keys', methods=['GET', 'POST'])
def manage_keys():
    if request.method == 'POST':
        save_keys(request.json)
        return jsonify({"status": "success"})
    return jsonify(load_keys())


def format_context_for_prompt(ctx):
    """Transforme le JSON context (dict) en texte pour le prompt IA."""
    import math as _math
    if not isinstance(ctx, dict):
        return str(ctx)

    symbol = ctx.get('symbol', 'N/A')
    tf = ctx.get('timeframe', 'N/A')
    lp = ctx.get('last_price')
    notes = ctx.get('notes') or "Aucune"
    active_strats = ctx.get('active_strategies', [])
    indicators = ctx.get('indicators', {})
    setups = ctx.get('setups', [])

    lines = []
    lines.append(f"Actif: {symbol} | Timeframe: {tf} | Dernier prix: {lp}")
    lines.append(f"Stratégies actives: {', '.join(active_strats) or 'Aucune'}")
    lines.append("Indicateurs clés:")
    for k, v in indicators.items():
        lines.append(f" - {k}: {v}")
    lines.append("Setups détectés:")
    if not setups:
        lines.append(" - Aucun setup actif.")
    else:
        for i, s in enumerate(setups, 1):
            rr = s.get("rr")
            rr_txt = f"{rr:.2f}" if isinstance(rr, (int, float, _math.floor(0).__class__)) else rr
            lines.append(
                f" {i}) {s.get('type')} @ {s.get('entry')} | SL {s.get('sl')} | "
                f"TP {s.get('tp')} | RR≈{rr_txt} | "
                f"Stars {s.get('stars')} | Source: {s.get('source')} | "
                f"Raison: {s.get('reason')}"
            )
    lines.append(f"Notes du trader: {notes}")
    return "\n".join(lines)



# ==========================================
# 📊 MOTEUR PYTHON SMC (SMART MONEY CONCEPTS)
# ==========================================
@app.route('/api/smc', methods=['POST'])
def get_smc():
    if not SMC_AVAILABLE: 
        return jsonify({"error": "Librairie smartmoneyconcepts non installée."}), 500

    data = request.json or {}
    candles = data.get('candles')
    if not candles: 
        return jsonify({"error": "Aucune bougie fournie."}), 400

    try:
        t0 = time.perf_counter()
        # Convertir en DataFrame Pandas
        df = pd.DataFrame(candles)

        # S'assurer que les colonnes sont bien numériques
        for col in ['open', 'high', 'low', 'close', 'volume']:
            if col in df.columns: 
                df[col] = pd.to_numeric(df[col], errors='coerce')

        # Calcul des indicateurs institutionnels SMC
        fvg_df = smc.fvg(df)
        ob_df = smc.ob(df)

        # Remplacement robuste de tous les NaN et Infinity pour éviter le crash JSON (Erreur 500)
        fvg_clean = fvg_df.replace([float('inf'), float('-inf')], None).where(pd.notnull(fvg_df), None).to_dict(orient="records")
        ob_clean = ob_df.replace([float('inf'), float('-inf')], None).where(pd.notnull(ob_df), None).to_dict(orient="records")

        res = {"fvg": fvg_clean, "ob": ob_clean}
        logging.info(f"SMC Calculé en {time.perf_counter() - t0:.3f}s")
        return jsonify(res)
    except Exception as e:
        logging.error(f"Erreur Serveur SMC: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/api/analyze', methods=['POST'])
def analyze_chart():
    data = request.json or {}
    ai_type = data.get('ai_type')
    raw_context = data.get('context', '')
    strategy = data.get('strategy', 'SMC Multi-Stratégies')
    keys = load_keys()

    user_context = format_context_for_prompt(raw_context)

    # ===== Choix du prompt système selon la stratégie =====
    if "Builder Modulaire" in strategy:
        system_prompt = f"""
Tu es un Ingénieur Quantitatif. Modèle : {strategy}. Analyse les confluences mathématiques choisies par l'utilisateur (Algo, Variance, L2, Optimisation, Convexe, Linéaire).
Réponds UNIQUEMENT avec ce format HTML :

<div style="color:white;">
  <div style="margin-bottom:8px;"><b>Verdict Custom :</b> Attendre / Entrer LONG / Entrer SHORT</div>
  <div style="margin-bottom:8px;"><b>Entrée Opti. :</b> Prix</div>
  <div style="margin-bottom:8px;"><b>Stop Loss :</b> Prix</div>
  <div style="margin-bottom:8px;"><b>Take Profit :</b> Prix projet</div>

  <div style="margin-top:10px; padding-top:10px; border-top:1px solid #4a5056; font-style:italic; color:#fdd835;">
    <b>Analyse des Confluences :</b> Explique pourquoi les briques sélectionnées s'alignent.
  </div>
</div>
"""
    elif "Quant V2" in strategy:
        system_prompt = f"""
Tu es un Lead Quant Researcher. Modèle : {strategy}. Analyse les données du modèle V2 (Filtre de Kalman, Lambda Dynamique ATR, Convexité 2nd degré).
Réponds UNIQUEMENT avec ce format HTML :

<div style="color:white;">
  <div style="margin-bottom:8px;"><b>Verdict Quant V2 :</b> Attendre / Entrer LONG / Entrer SHORT</div>
  <div style="margin-bottom:8px;"><b>Entrée Opti. :</b> Prix</div>
  <div style="margin-bottom:8px;"><b>Stop Loss :</b> Prix</div>
  <div style="margin-bottom:8px;"><b>Take Profit :</b> Prix projet</div>

  <div style="margin-top:10px; padding-top:10px; border-top:1px solid #4a5056; font-style:italic; color:#00e5ff;">
    <b>Thèse Algorithmique :</b> Explique la probabilité et la convexité polynomiale.
  </div>
</div>
"""
    elif "Quant" in strategy:
        system_prompt = f"""
Tu es un Ingénieur Quantitatif. Modèle ciblé : {strategy}. Analyse les probabilités (Régression L2, Optimisation Convexe, POC).
Réponds UNIQUEMENT avec ce format HTML :

<div style="color:white;">
  <div style="margin-bottom:8px;"><b>Verdict Quant :</b> Attendre / Entrer LONG / Entrer SHORT</div>
  <div style="margin-bottom:8px;"><b>Entrée Opti. :</b> Prix</div>
  <div style="margin-bottom:8px;"><b>Stop Loss :</b> Prix</div>
  <div style="margin-bottom:8px;"><b>Take Profit :</b> Prix</div>

  <div style="margin-top:10px; padding-top:10px; border-top:1px solid #4a5056; font-style:italic; color:#e040fb;">
    <b>Thèse Mathématique :</b> Explique la convergence L2 et le POC.
  </div>
</div>
"""
    elif "ICT BPR" in strategy:
        system_prompt = f"""
Tu es un Spécialiste ICT (Inner Circle Trader). Stratégie ciblée : {strategy}.
Analyse le marché selon le prisme algorithmique ICT (Time & Price, liquidité, FVG/SIBI/BISI, BPR).
Réponds UNIQUEMENT avec ce format HTML :

<div style="color:white;">
  <div style="margin-bottom:8px;"><b>Verdict ICT BPR :</b> Attendre / Entrer LONG / Entrer SHORT</div>
  <div style="margin-bottom:8px;"><b>Entrée Opti. Zone BPR :</b> Prix d'entrée sur le BPR</div>
  <div style="margin-bottom:8px;"><b>Stop Loss :</b> Prix invalidant la macro algorithmique</div>
  <div style="margin-bottom:8px;"><b>Take Profit :</b> Cible vers la Buyside/Sellside Liquidity</div>

  <div style="margin-top:10px; padding-top:10px; border-top:1px solid #4a5056; font-style:italic; color:#ff9800;">
    <b>Logique Algorithmique :</b> Explique la manipulation temporelle récente, le FVG comblé/repricing, et pourquoi le prix est attiré par la prochaine liquidité.
  </div>
</div>
"""
    elif "SMC Liquidity V2" in strategy:
        system_prompt = f"""
Tu es un Trader Institutionnel expert en Smart Money Concepts (SMC). Stratégie ciblée : {strategy}.
Analyse les chasses aux stops (Liquidity Sweeps), la tendance de fond et les zones OTE (0.618-0.786).
Réponds UNIQUEMENT avec ce format HTML :

<div style="color:white;">
  <div style="margin-bottom:8px;"><b>Verdict SMC V2 :</b> Attendre le Grab / Entrer LONG / Entrer SHORT</div>
  <div style="margin-bottom:8px;"><b>Entrée Opti. Zone OTE :</b> Prix d'entrée dans les 0.618-0.786</div>
  <div style="margin-bottom:8px;"><b>Stop Loss :</b> Prix au-dessus/en-dessous du sweep</div>
  <div style="margin-bottom:8px;"><b>Take Profit :</b> Cible vers la liquidité opposée</div>

  <div style="margin-top:10px; padding-top:10px; border-top:1px solid #4a5056; font-style:italic; color:#00bcd4;">
    <b>Analyse Liquidity Sweep :</b> Explique quelle liquidité a été chassée, la réaction du prix et le ciblage de la liquidité opposée.
  </div>
</div>
"""
    else:
        system_prompt = f"""
Tu es un Coach de Trading SMC. Stratégies ciblées : {strategy}. Analyse les confluences fournies.
Réponds UNIQUEMENT avec ce format HTML :

<div style="color:white;">
  <div style="margin-bottom:8px;"><b>Verdict IA :</b> Attendre / Entrer LONG / Entrer SHORT</div>
  <div style="margin-bottom:8px;"><b>Entrée :</b> Prix</div>
  <div style="margin-bottom:8px;"><b>Stop Loss :</b> Prix</div>
  <div style="margin-bottom:8px;"><b>Take Profit :</b> Prix</div>

  <div style="margin-top:10px; padding-top:10px; border-top:1px solid #4a5056; font-style:italic; color:#ff9800;">
    <b>Analyse Institutionnelle :</b> Explique les confluences OB, FVG, Liquidity.
  </div>
</div>
"""

    # Injection de la mémoire du coach
    memory_summary = get_coach_memory_summary()
    system_prompt = system_prompt + "\n\n" + memory_summary

    try:
        if ai_type == "deepseek":
            if not keys.get("deepseek_key"):
                return jsonify(error="Clé Deepseek manquante."), 400

            client = OpenAI(
                api_key=keys.get("deepseek_key"),
                base_url="https://api.deepseek.com",
            )
            response = client.chat.completions.create(
                model=keys.get("deepseek_model", "deepseek-chat"),
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_context},
                ],
                stream=False,
                max_tokens=450,
                temperature=0.3,
            )
            return jsonify(html=response.choices[0].message.content)

        elif ai_type == "grok":
            if not keys.get("grok_key"):
                return jsonify(error="Clé Grok manquante."), 400

            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {keys.get('grok_key')}",
            }
            payload = {
                "model": keys.get("grok_model", "grok-beta"),
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_context},
                ],
                "stream": False,
                "temperature": 0.3,
            }
            grok_req = requests.post(
                "https://api.x.ai/v1/chat/completions",
                headers=headers,
                json=payload,
            )
            grok_res = grok_req.json()
            if grok_req.status_code == 200:
                content = grok_res["choices"][0]["message"]["content"]
                return jsonify(html=content)
            else:
                return jsonify(
                    error=f"Erreur Grok {grok_res.get('error', 'Erreur')}"
                ), 400

        else:
            return jsonify(error="Type d'IA invalide"), 400

    except Exception as e:
        return jsonify(error=f"Erreur Serveur : {str(e)}"), 500


@app.route('/api/slparams', methods=['GET'])
def optimize_sl():
    try:
        if not os.path.exists(MEMORY_FILE):
            open(MEMORY_FILE, 'w', encoding='utf-8').close()

        with open(MEMORY_FILE, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        trades = [json.loads(line) for line in lines if line.strip()]

        atr_mult = 2.0
        rr_target = 2.0

        if len(trades) >= 3:
            losses = [t for t in trades if t.get('result') == 'LOSS']
            winrate = (len(trades) - len(losses)) / len(trades)

            if winrate < 0.40:
                atr_mult = 3.0
            elif winrate > 0.65:
                atr_mult = 1.5
            else:
                atr_mult = 2.2

        return jsonify(
            atrmultiplier=atr_mult,
            rrtarget=rr_target,
            tradescount=len(trades),
        )
    except Exception as e:
        return jsonify(atrmultiplier=2.0, rrtarget=2.0, error=str(e))


@app.route('/api/learn', methods=['POST'])
def learn_from_trade():
    data = request.json
    try:
        with open(MEMORY_FILE, 'a', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
            f.write("\n")
        return jsonify(status="success")
    except Exception as e:
        return jsonify(error=str(e)), 500




@app.route('/api/market/history', methods=['GET'])
def market_history():
    source = (request.args.get('source') or 'binance').lower()
    symbol = (request.args.get('symbol') or 'BTCUSDT').upper()
    interval = request.args.get('interval') or '1m'
    limit = int(request.args.get('limit', 1000))

    try:
        if source == 'binance':
            candles = fetch_binance_history(symbol, interval, limit)
        elif source == 'kraken':
            candles = fetch_kraken_history(symbol, interval, limit)
        elif source == 'merged':
            binance_candles = fetch_binance_history(symbol, interval, limit)
            kraken_candles = fetch_kraken_history(symbol, interval, min(limit, 720))
            candles = merge_candles(binance_candles, kraken_candles)
        else:
            return jsonify(error='Source invalide. Utilise binance, kraken ou merged.'), 400

        return jsonify(
            source=source,
            symbol=symbol,
            interval=interval,
            count=len(candles),
            candles=candles,
        )
    except Exception as e:
        return jsonify(error=str(e)), 400


@app.route('/')
def index():
    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True)


@app.route('/api/fuse', methods=['POST'])
def fuse_endpoint():
    data = request.json or {}
    active_strats = data.get('strategies', [])
    context = data.get('context', '')
    use_ai = data.get('use_ai', True)

    try:
        engine = FusionEngine(use_ai=use_ai, api_keys=load_keys())
        result = engine.fuse_strategies(active_strats, context)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
