import os
import json
import requests
import math
import time
import logging
from collections import defaultdict
from flask import Flask, render_template, request, jsonify
from openai import OpenAI
import functools

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

try:
    from fusion_engine import FusionEngine, MemoryManager
except ImportError:
    pass

try:
    import pandas as pd
    from smartmoneyconcepts import smc
    SMC_AVAILABLE = True
except ImportError:
    SMC_AVAILABLE = False

# --- OPTIMISATION 3 : BASE DE DONNÉES VECTORIELLE (RAG) ---
try:
    import chromadb
    CHROMA_AVAILABLE = True
except ImportError:
    CHROMA_AVAILABLE = False

app = Flask(__name__)
MEMORY_FILE = "coach_memory.dat"
KEYS_FILE = "api_keys.json"

class VectorMemoryManager:
    def __init__(self):
        self.trades = []
        self.db_path = "./vectordb"
        self.collection = None

        if CHROMA_AVAILABLE:
            try:
                # Initialise la base de données vectorielle locale
                self.client = chromadb.PersistentClient(path=self.db_path)
                self.collection = self.client.get_or_create_collection(name="coach_trades")
                logging.info(f"Base Vectorielle prête. {self.collection.count()} souvenirs encodés.")
            except Exception as e:
                logging.error(f"Erreur d'initialisation ChromaDB: {e}")

        # On charge toujours le vieux fichier pour la compatibilité
        self.load_legacy()

        # Migration automatique du vieux fichier vers la base vectorielle si elle est vide
        if CHROMA_AVAILABLE and self.collection and self.collection.count() < len(self.trades):
            logging.info("Migration des anciens trades vers la base vectorielle...")
            self.migrate_to_vector_db()

    def load_legacy(self):
        if not os.path.exists(MEMORY_FILE):
            open(MEMORY_FILE, 'w', encoding='utf-8').close()
        try:
            with open(MEMORY_FILE, 'r', encoding='utf-8') as f:
                self.trades = [json.loads(line) for line in f.readlines() if line.strip()]
        except Exception as e:
            logging.error(f"Erreur lecture legacy: {e}")

    def migrate_to_vector_db(self):
        for i, t in enumerate(self.trades):
            trade_id = str(t.get('time', f"legacy_{i}"))
            try:
                doc_text = f"Setup {t.get('type')} sur stratégie {t.get('strategy', 'Inconnue')}. Raison : {t.get('reason', '')}"
                meta = {
                    "result": t.get("result", "UNKNOWN"),
                    "type": t.get("type", "UNKNOWN")
                }
                self.collection.upsert(
                    documents=[doc_text],
                    metadatas=[meta],
                    ids=[trade_id]
                )
            except Exception as e:
                pass

    def add_trade(self, trade):
        self.trades.append(trade)
        # Sauvegarde classique
        try:
            with open(MEMORY_FILE, 'a', encoding='utf-8') as f:
                json.dump(trade, f, ensure_ascii=False)
                f.write('\n')
        except Exception: pass

        # Sauvegarde Vectorielle instantanée
        if CHROMA_AVAILABLE and self.collection:
            trade_id = str(trade.get('time', time.time()))
            doc_text = f"Setup {trade.get('type')} sur stratégie {trade.get('strategy', 'Inconnue')}. Raison : {trade.get('reason', '')}"
            meta = {
                "result": trade.get("result", "UNKNOWN"),
                "type": trade.get("type", "UNKNOWN")
            }
            try:
                self.collection.add(documents=[doc_text], metadatas=[meta], ids=[trade_id])
            except Exception as e:
                logging.error(f"Erreur ajout vectoriel: {e}")

    def get_similar_situations(self, current_context_text, k=3):
        if not CHROMA_AVAILABLE or not self.collection or self.collection.count() == 0:
            return None

        try:
            results = self.collection.query(
                query_texts=[current_context_text],
                n_results=min(k, self.collection.count())
            )
            return results
        except Exception as e:
            logging.error(f"Erreur requête vectorielle: {e}")
            return None

memory_cache = VectorMemoryManager()

def get_rag_prompt(user_context):
    base_stats = "\n\n[STATISTIQUES GLOBALES]\n"
    total = len(memory_cache.trades)
    if total > 0:
        wins = len([t for t in memory_cache.trades if t.get('result') == 'WIN'])
        base_stats += f"Total trades: {total} | Taux de réussite: {(wins/total)*100:.1f}%\n"

    rag_section = ""
    similar_data = memory_cache.get_similar_situations(user_context, k=3)

    if similar_data and similar_data['documents'] and len(similar_data['documents'][0]) > 0:
        rag_section += "\n[MÉMOIRE VECTORIELLE - SITUATIONS SIMILAIRES TROUVÉES DANS LE PASSÉ]\n"
        rag_section += "J'ai cherché dans ma base de données des situations de marché mathématiquement similaires à celle d'aujourd'hui :\n"

        docs = similar_data['documents'][0]
        metas = similar_data['metadatas'][0]

        for i in range(len(docs)):
            resultat = metas[i].get('result', 'UNKNOWN')
            rag_section += f"- Souvenir {i+1} : Le trade s'était soldé par un {resultat}. Contexte d'époque : {docs[i]}\n"

        rag_section += "\n-> Utilise ces souvenirs spécifiques pour valider ou rejeter le trade actuel. Si les situations passées similaires ont conduit à des LOSS, sois extrêmement prudent et n'hésite pas à conseiller de ne pas entrer.\n"
    else:
        losses = [t for t in memory_cache.trades if t.get('result') == 'LOSS']
        recent_losses = losses[-3:]
        if recent_losses:
            rag_section += "\n[DERNIÈRES ERREURS (Fallback)]\n"
            for l in recent_losses:
                rag_section += f"- Setup {l.get('type')} basé sur '{l.get('reason')}'.\n"

    return base_stats + rag_section

@functools.lru_cache(maxsize=32)
def fetch_binance_history_cached(symbol, interval, limit):
    response = requests.get(
        "https://data-api.binance.vision/api/v3/klines",
        params={"symbol": symbol, "interval": interval, "limit": limit},
        timeout=5,
    )
    response.raise_for_status()
    return response.json()

def normalize_binance_klines(rows):
    return [{
        "time": int(row[0] // 1000),
        "open": float(row[1]), "high": float(row[2]),
        "low": float(row[3]), "close": float(row[4]),
        "volume": float(row[5]), "source": "binance",
    } for row in (rows or [])]

def fetch_binance_history(symbol, interval, limit=1000):
    try:
        rows = fetch_binance_history_cached(symbol, interval, min(int(limit), 1000))
        return normalize_binance_klines(rows)
    except requests.exceptions.Timeout:
        logging.error("Timeout Binance API")
        raise ValueError("Binance API Timeout")
    except Exception as e:
        logging.error(f"Erreur Binance: {e}")
        raise ValueError(f"Erreur Binance: {e}")

KRAKEN_SYMBOL_MAP = { "BTCUSDT": "BTC/USDT", "ETHUSDT": "ETH/USDT", "SOLUSDT": "SOL/USDT", "XRPUSDT": "XRP/USDT", "DOGEUSDT": "DOGE/USDT" }
KRAKEN_INTERVAL_MAP = { "1m": 1, "5m": 5, "15m": 15, "30m": 30, "1h": 60, "4h": 240 }

def fetch_kraken_history(symbol, interval, limit=720):
    kraken_symbol = KRAKEN_SYMBOL_MAP.get(symbol)
    kraken_interval = KRAKEN_INTERVAL_MAP.get(interval)
    if not kraken_symbol or not kraken_interval:
        raise ValueError("Symbole ou intervalle Kraken non supporté")
    try:
        response = requests.get(
            "https://api.kraken.com/0/public/OHLC",
            params={"pair": kraken_symbol, "interval": kraken_interval},
            timeout=5,
        )
        response.raise_for_status()
        payload = response.json()
        if payload.get("error"): raise ValueError(", ".join(payload["error"]))
        result = payload.get("result", {})
        pair_keys = [k for k in result.keys() if k != "last"]
        if not pair_keys: return []
        rows = result[pair_keys[0]]
        candles = [{"time": int(float(row[0])), "open": float(row[1]), "high": float(row[2]), "low": float(row[3]), "close": float(row[4]), "volume": float(row[6]), "source": "kraken"} for row in rows]
        return candles[-min(int(limit), 720):]
    except Exception as e:
        logging.error(f"Erreur Kraken: {e}")
        raise ValueError(f"Erreur Kraken: {e}")

def merge_candles(binance_candles, kraken_candles):
    grouped = defaultdict(list)
    for c in (binance_candles or []): grouped[c["time"]].append(c)
    for c in (kraken_candles or []): grouped[c["time"]].append(c)

    merged = []
    for ts in sorted(grouped.keys()):
        items = grouped[ts]
        l = len(items)
        merged.append({
            "time": ts,
            "open": sum(x["open"] for x in items) / l,
            "high": sum(x["high"] for x in items) / l,
            "low": sum(x["low"] for x in items) / l,
            "close": sum(x["close"] for x in items) / l,
            "volume": sum(x["volume"] for x in items),
            "source": "merged" if l > 1 else items[0].get("source", "merged"),
        })
    return merged

def load_keys():
    if os.path.exists(KEYS_FILE):
        with open(KEYS_FILE, 'r') as f:
            return json.load(f)
    return { "deepseek_key": "", "grok_key": "", "deepseek_model": "deepseek-chat", "grok_model": "grok-beta" }

def save_keys(keys):
    with open(KEYS_FILE, 'w') as f:
        json.dump(keys, f)

@app.route('/api/keys', methods=['GET', 'POST'])
def manage_keys():
    if request.method == 'POST':
        save_keys(request.json)
        return jsonify({"status": "success"})
    return jsonify(load_keys())

@app.route('/api/smc', methods=['POST'])
def get_smc():
    if not SMC_AVAILABLE: return jsonify({"error": "smartmoneyconcepts non installé."}), 500
    data = request.json or {}
    candles = data.get('candles')
    if not candles: return jsonify({"error": "Aucune bougie fournie."}), 400

    try:
        t0 = time.perf_counter()
        df = pd.DataFrame(candles)
        for col in ['open', 'high', 'low', 'close', 'volume']:
            if col in df.columns: df[col] = pd.to_numeric(df[col], errors='coerce')

        fvg_df = smc.fvg(df)
        ob_df = smc.ob(df)

        def clean_df(dataframe): return dataframe.where(pd.notnull(dataframe), None).to_dict(orient="records")

        res = {"fvg": clean_df(fvg_df), "ob": clean_df(ob_df)}
        logging.info(f"SMC Calculé en {time.perf_counter() - t0:.3f}s")
        return jsonify(res)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/analyze', methods=['POST'])
def analyze_chart():
    data = request.json or {}
    ai_type = data.get('ai_type')
    strategy = data.get('strategy', 'SMC')
    keys = load_keys()

    # Construction du contexte avec RAG
    user_context = str(data.get('context', ''))
    rag_summary = get_rag_prompt(user_context)
    full_prompt_context = user_context + rag_summary

    try:
        if ai_type == 'deepseek':
            if not keys.get('deepseek_key'): return jsonify({"error": "Clé Deepseek manquante."}), 400
            client = OpenAI(api_key=keys.get('deepseek_key'), base_url="https://api.deepseek.com", timeout=10.0)
            response = client.chat.completions.create(
                model=keys.get('deepseek_model', 'deepseek-chat'),
                messages=[{"role": "system", "content": f"Tu es un Expert. Stratégie: {strategy}"}, {"role": "user", "content": full_prompt_context}],
                max_tokens=450, temperature=0.3
            )
            return jsonify({"html": response.choices[0].message.content})

        elif ai_type == 'grok':
            if not keys.get('grok_key'): return jsonify({"error": "Clé Grok manquante."}), 400
            headers = {"Content-Type": "application/json", "Authorization": f"Bearer {keys.get('grok_key')}"}
            payload = {
                "model": keys.get('grok_model', 'grok-beta'),
                "messages": [{"role": "system", "content": f"Expert. Stratégie: {strategy}"}, {"role": "user", "content": full_prompt_context}],
                "temperature": 0.3
            }
            grok_req = requests.post("https://api.x.ai/v1/chat/completions", headers=headers, json=payload, timeout=5.0)
            grok_req.raise_for_status()
            return jsonify({"html": grok_req.json()['choices'][0]['message']['content']})

        else:
            return jsonify({"error": "Type d'IA invalide"}), 400

    except requests.exceptions.Timeout:
        logging.warning(f"Timeout sur l'API {ai_type}, passage en mode dégradé local.")
        return jsonify({"html": "<div style='color:#ef5350;'>Erreur: L'IA n'a pas répondu assez vite. Le scanner local prend le relais de façon autonome.</div>"})
    except Exception as e:
        logging.error(f"Erreur API IA : {e}")
        return jsonify({"error": f"Erreur Serveur: {str(e)}"}), 500

@app.route('/api/sl_params', methods=['GET'])
def optimize_sl():
    try:
        trades = memory_cache.trades
        atr_mult, rr_target = 2.0, 2.0
        if len(trades) >= 3:
            losses = [t for t in trades if t.get('result') == 'LOSS']
            win_rate = (len(trades) - len(losses)) / len(trades)
            if win_rate < 0.40: atr_mult = 3.0
            elif win_rate > 0.65: atr_mult = 1.5
            else: atr_mult = 2.2
        return jsonify({"atr_multiplier": atr_mult, "rr_target": rr_target, "trades_count": len(trades)})
    except Exception as e:
        return jsonify({"atr_multiplier": 2.0, "rr_target": 2.0, "error": str(e)})

@app.route('/api/learn', methods=['POST'])
def learn_from_trade():
    try:
        data = request.json
        if data:
            memory_cache.add_trade(data)
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/market/history', methods=['GET'])
def market_history():
    source = request.args.get('source', 'binance').lower()
    symbol = request.args.get('symbol', 'BTCUSDT').upper()
    interval = request.args.get('interval', '1m')
    limit = int(request.args.get('limit', 1000))

    try:
        t0 = time.perf_counter()
        if source == 'binance': candles = fetch_binance_history(symbol, interval, limit)
        elif source == 'kraken': candles = fetch_kraken_history(symbol, interval, limit)
        elif source == 'merged':
            c_bin = fetch_binance_history(symbol, interval, limit)
            c_kra = fetch_kraken_history(symbol, interval, min(limit, 720))
            candles = merge_candles(c_bin, c_kra)
        else:
            return jsonify({"error": "Source invalide."}), 400

        logging.info(f"Market data chargée en {time.perf_counter() - t0:.3f}s")
        return jsonify({"source": source, "symbol": symbol, "interval": interval, "count": len(candles), "candles": candles})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/api/fuse', methods=['POST'])
def fuse_endpoint():
    data = request.json or {}
    active_strats = data.get('strategies', [])
    context = data.get('context', {})
    use_ai = data.get('use_ai', True)

    if len(active_strats) > 10:
        return jsonify({"error": "Limite de 10 stratégies simultanées atteinte. Désactivez-en pour continuer."}), 400

    try:
        t0 = time.perf_counter()
        result = {"decision": "Attendre", "confidence": "0%", "reason": "Moteur non lié"}
        if 'FusionEngine' in globals():
            engine = FusionEngine(use_ai=use_ai, api_keys=load_keys())
            result = engine.fuse_strategies(active_strats, context)

        logging.info(f"Fusion ({len(active_strats)} strats) terminée en {time.perf_counter() - t0:.3f}s")
        return jsonify(result)
    except Exception as e:
        logging.error(f"Erreur Fusion : {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/')
def index(): return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True, threaded=True)
