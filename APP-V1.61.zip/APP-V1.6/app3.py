import os
import json
import requests
import math
from collections import defaultdict
from flask import Flask, render_template, request, jsonify
from openai import OpenAI

# --- TENTATIVE D'IMPORTATION DE SMC ---
try:
    import pandas as pd
    import time
    import logging
    from smartmoneyconcepts import smc
    SMC_AVAILABLE = True
except ImportError:
    SMC_AVAILABLE = False
    print("⚠️ 'pandas' ou 'smartmoneyconcepts' non installé. Le moteur SMC Python sera désactivé.")

try:
    from fusion_engine import FusionEngine, MemoryManager
except ImportError:
    pass

app = Flask(__name__)

MEMORY_FILE = "coach_memory.dat"

# Création du fichier au démarrage s'il n'existe pas
if not os.path.exists(MEMORY_FILE):
    open(MEMORY_FILE, 'w', encoding='utf-8').close()


def get_coach_memory_summary():
    try:
        with open(MEMORY_FILE, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            if not lines:
                return "Aucune mémoire passée."
            return "".join(lines[-10:])
    except:
        return "Impossible de lire la mémoire."


def append_coach_memory(text):
    try:
        with open(MEMORY_FILE, 'a', encoding='utf-8') as f:
            f.write(text + "\n")
    except:
        pass


def call_deepseek_api(system_prompt, user_prompt):
    # Remplacer par votre vraie clé
    api_key = "sk-07ed9b7bb699479b94090dc15a818c21"
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": 0.3
    }
    
    try:
        resp = requests.post("https://api.deepseek.com/v1/chat/completions", headers=headers, json=payload, timeout=20)
        if resp.status_code == 200:
            return {"status": "success", "response": resp.json()['choices'][0]['message']['content']}
        else:
            return {"status": "error", "message": f"HTTP {resp.status_code}: {resp.text}"}
    except Exception as e:
        return {"status": "error", "message": str(e)}

def call_grok_api(system_prompt, user_prompt):
    api_key = "xai-w1v5f2jZtqA9J2j0yXzGkXnL2E4R3c5v7F8m1B9hX2v4R5j3N6kP9xM7aT4yV3zQ2"
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": "grok-2-latest",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": 0.3
    }
    
    try:
        resp = requests.post("https://api.x.ai/v1/chat/completions", headers=headers, json=payload, timeout=20)
        if resp.status_code == 200:
            return {"status": "success", "response": resp.json()['choices'][0]['message']['content']}
        else:
            return {"status": "error", "message": f"HTTP {resp.status_code}: {resp.text}"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


@app.route('/')
def index():
    return send_from_directory('.', 'index.html')


@app.route('/<path:filename>')
def serve_static(filename):
    if os.path.exists(filename):
        return send_from_directory('.', filename)
    return "File not found", 404


@app.route('/api/market/history', methods=['GET'])
def get_market_history():
    source = request.args.get('source', 'binance')
    symbol = request.args.get('symbol', 'BTCUSDT')
    interval = request.args.get('interval', '5m')
    limit = int(request.args.get('limit', 1000))
    
    if source == 'binance':
        return jsonify(fetch_binance_history(symbol, interval, limit))
    elif source == 'kraken':
        return jsonify(fetch_kraken_history(symbol, interval, limit))
    elif source == 'merged':
        binance_data = fetch_binance_history(symbol, interval, limit)
        kraken_data = fetch_kraken_history(symbol, interval, limit)
        
        if "error" in binance_data and "error" in kraken_data:
             return jsonify({"error": "Failed to fetch from both sources"})
        elif "error" in binance_data:
             return jsonify(kraken_data)
        elif "error" in kraken_data:
             return jsonify(binance_data)
             
        merged_candles = []
        b_dict = {c['time']: c for c in binance_data.get('candles', [])}
        k_dict = {c['time']: c for c in kraken_data.get('candles', [])}
        
        all_times = sorted(list(set(b_dict.keys()) | set(k_dict.keys())))
        
        for t in all_times:
            b = b_dict.get(t)
            k = k_dict.get(t)
            
            if b and k:
                merged_candles.append({
                    "time": t,
                    "open": (b['open'] + k['open']) / 2,
                    "high": (b['high'] + k['high']) / 2,
                    "low": (b['low'] + k['low']) / 2,
                    "close": (b['close'] + k['close']) / 2,
                    "volume": b['volume'] + k['volume'],
                    "source": "merged"
                })
            elif b:
                b['source'] = 'binance_only'
                merged_candles.append(b)
            elif k:
                k['source'] = 'kraken_only'
                merged_candles.append(k)
                
        return jsonify({"candles": merged_candles})
    else:
        return jsonify({"error": "Unknown source"}), 400


# ==========================================
# 📊 MOTEUR PYTHON SMC (SMART MONEY CONCEPTS)
# ==========================================
@app.route('/api/smc', methods=['POST'])
def get_smc():
    if not SMC_AVAILABLE: 
        return jsonify({"error": "Librairie smartmoneyconcepts non installée."}), 500
        
    data = request.json or {}
    candles = data.get('candles')
    if not candles: 
        return jsonify({"error": "Aucune bougie fournie."}), 400

    try:
        t0 = time.perf_counter()
        # Convertir en DataFrame Pandas
        df = pd.DataFrame(candles)
        
        # S'assurer que les colonnes sont bien numériques
        for col in ['open', 'high', 'low', 'close', 'volume']:
            if col in df.columns: 
                df[col] = pd.to_numeric(df[col], errors='coerce')

        # Calcul des indicateurs institutionnels SMC
        fvg_df = smc.fvg(df)
        ob_df = smc.ob(df)

        # Remplacement robuste de tous les NaN et Infinity pour éviter le crash JSON (Erreur 500)
        fvg_clean = fvg_df.replace([float('inf'), float('-inf')], None).where(pd.notnull(fvg_df), None).to_dict(orient="records")
        ob_clean = ob_df.replace([float('inf'), float('-inf')], None).where(pd.notnull(ob_df), None).to_dict(orient="records")

        res = {"fvg": fvg_clean, "ob": ob_clean}
        return jsonify(res)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/analyze', methods=['POST'])
def analyze_chart():
    data = request.json
    if not data:
        return jsonify({"error": "No data provided"}), 400
        
    ai_model = data.get('model', 'deepseek')
    market_context = data.get('context', '')
    setup_details = data.get('setup', {})
    chart_metrics = data.get('metrics', {})
    
    memory_context = get_coach_memory_summary()
    
    system_prompt = """Tu es un Quant Trader Institutionnel Senior et un Mentor de Trading impitoyable.
Ta mission est de valider ou de détruire le setup de trading que le système mécanique vient de trouver.

RÈGLES ABSOLUES:
1. Ne fais pas d'introduction polie. Va droit au but.
2. Si le ratio Risque/Récompense est inférieur à 2.0, c'est un REFUS IMMÉDIAT.
3. Si le trade est contre la tendance lourde sans preuve de manipulation de liquidité, c'est un REFUS IMMÉDIAT.
4. Structure ta réponse avec des sauts de ligne clairs.
5. Termine toujours par l'un de ces trois verdicts (en majuscules) : 
   - 🟢 FEU VERT : EXECUTION IMMEDIATE
   - 🟡 SOUS SURVEILLANCE : ATTENDRE CONFIRMATION
   - 🔴 ANNULATION : TRADE TOXIQUE
"""

    user_prompt = f"""
ANALYSE REQUISE IMMÉDIATE.

CONTEXTE MARCHÉ (Basé sur les données en temps réel) :
{market_context}

MÉMOIRE DU COACH (Trades et erreurs récentes) :
{memory_context}

LE SETUP PROPOSÉ :
- Type : {setup_details.get('type', 'Inconnu')}
- Raison Algorithmique : {setup_details.get('reason', 'Non spécifiée')}
- Prix d'Entrée : {setup_details.get('entry', 'N/A')}
- Stop Loss : {setup_details.get('sl', 'N/A')}
- Take Profit : {setup_details.get('tp', 'N/A')}
- Étoiles (Force) : {setup_details.get('stars', '?')}/5

DÉCISION ?
"""

    if ai_model == 'grok':
        result = call_grok_api(system_prompt, user_prompt)
    else:
        result = call_deepseek_api(system_prompt, user_prompt)
        
    if result["status"] == "success":
        summary = f"[{ai_model.upper()}] Setup {setup_details.get('type')} sur {setup_details.get('entry')}. Verdict donné."
        append_coach_memory(summary)
        
    return jsonify(result)

def fetch_binance_history(symbol, interval, limit):
    url = "https://api.binance.com/api/v3/klines"
    b_interval = interval
    b_symbol = symbol.replace('/', '')
    
    params = {"symbol": b_symbol, "interval": b_interval, "limit": limit}
    try:
        resp = requests.get(url, params=params, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            candles = []
            for row in data:
                candles.append({
                    "time": int(row[0] / 1000),
                    "open": float(row[1]),
                    "high": float(row[2]),
                    "low": float(row[3]),
                    "close": float(row[4]),
                    "volume": float(row[5]),
                    "source": "binance"
                })
            return {"candles": candles}
        else:
            return {"error": f"Binance error: {resp.text}"}
    except Exception as e:
        return {"error": str(e)}

def fetch_kraken_history(symbol, interval, limit):
    url = "https://api.kraken.com/0/public/OHLC"
    k_interval_map = {'1m': 1, '3m': 3, '5m': 5, '15m': 15, '30m': 30, '1h': 60, '4h': 240, '1d': 1440}
    
    k_interval = k_interval_map.get(interval.lower())
    if not k_interval:
        return {"error": f"Interval {interval} not supported by Kraken mapping."}
        
    k_symbol = symbol.replace('/', '')
    if k_symbol == 'BTCUSDT': k_symbol = 'XBTUSDT'
    
    params = {"pair": k_symbol, "interval": k_interval}
    try:
        resp = requests.get(url, params=params, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            if data.get('error'):
                return {"error": "Kraken API Error: " + ", ".join(data['error'])}
                
            pair_key = list(data['result'].keys())[0]
            if pair_key == 'last': pair_key = list(data['result'].keys())[1]
            
            raw_candles = data['result'][pair_key]
            candles = []
            
            for row in raw_candles[-limit:]:
                candles.append({
                    "time": int(row[0]),
                    "open": float(row[1]),
                    "high": float(row[2]),
                    "low": float(row[3]),
                    "close": float(row[4]),
                    "volume": float(row[6]),
                    "source": "kraken"
                })
            return {"candles": candles}
        else:
            return {"error": f"Kraken error: {resp.status_code}"}
    except Exception as e:
        return {"error": str(e)}

if __name__ == '__main__':
    print("🚀 DÉMARRAGE DU TERMINAL DE TRADING HYBRIDE...")
    print(f"✅ Moteur SMC Python disponible : {SMC_AVAILABLE}")
    print("Accédez à l'interface via : http://127.0.0.1:5000")
    app.run(debug=True, port=5000)
